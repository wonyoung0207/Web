import 'package:alcohol_project/models/Board.dart';
import 'package:flutter/material.dart';

class BoarderTile extends StatelessWidget {
  //const BoarderTile({Key? key}) : super(key: key);


  final Board board;
  BoarderTile({ required this.board });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top : 8.0),
      child: Card(
        margin: EdgeInsets.fromLTRB(20.0, 6.0, 20.0, 0.0),
        child: ListTile(
          leading: CircleAvatar(

            radius: 25.0,
            //backgroundColor: Colors.brown[person.score],
            //backgroundColor: Colors.brown[person_top3.score],

            backgroundImage: AssetImage('assets/${board.avatar_choose()}.png'),
          ),

          title: Text(
            '${board.title}',
            style: TextStyle(
              fontSize: 18.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          subtitle: Text(
            '${board.text}\n${board.date}',
            style: TextStyle(
              fontSize: 14.0,
              color: Colors.black,
            ),
          ),

        ),
      ),
    );
  }
}




// class BoarderTile extends StatefulWidget {
//   //const BoarderTile({Key? key}) : super(key: key);
//
//   @override
//   _BoarderTileState createState() => _BoarderTileState();
// }
//
// class _BoarderTileState extends State<BoarderTile> {

//
//   @override
//   Widget build(BuildContext context) {
//
//
//   }
// }
