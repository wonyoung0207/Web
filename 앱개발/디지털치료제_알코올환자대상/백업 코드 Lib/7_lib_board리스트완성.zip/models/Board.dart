class Board{

  late final String date;
  late final String name;
  late final String uid;
  late final String text;
  late final String title;



  Board({required this.name, required this.date,required this.uid,required this.text,required this.title});

}