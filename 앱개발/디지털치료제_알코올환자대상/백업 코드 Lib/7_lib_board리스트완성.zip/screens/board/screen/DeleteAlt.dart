import 'package:flutter/material.dart';


class DeleteAlt extends StatelessWidget {
  //const DeleteAlt({Key? key}) : super(key: key);


  final String uid;
  final String date;

  DeleteAlt({required this.uid, required this.date});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('삭제 경고'),
      content: Text("정말 삭제하시겠습니까? \n uid : ${this.uid} date : ${this.date}"),
      actions: <Widget>[
        FlatButton(
          child: Text('삭제'),
          onPressed: () {

            Navigator.pop(context);

          },
        ),
        FlatButton(
          child: Text('취소'),
          onPressed: () {
            //deleteId = '';
            Navigator.pop(context);
          },
        )
      ],
    );
  }
}