//
// class Person{
//   late final String name;
//   late final String age;
//   late final int score;
//   late final String uid;
//
//   Person({required this.name, required this.age, required this.score, required this.uid});
//
//
// }
class Person_Top3{
  late final String name;
  late final String age;
  late final int score;
  late final String uid;

  Person_Top3({required this.name, required this.age, required this.score,required this.uid});

}

class Person{
  late final String name;
  late final String age;
  late final int score;
  late final String uid;

  Person({required this.name, required this.age, required this.score,required this.uid});


}