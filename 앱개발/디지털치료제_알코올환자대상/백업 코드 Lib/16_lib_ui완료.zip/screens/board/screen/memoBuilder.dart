import 'package:alcohol_project/models/user.dart';
import 'package:alcohol_project/screens/board/screen/DeleteAlt.dart';
import 'package:alcohol_project/screens/home/boarderTile.dart';
import 'package:alcohol_project/service/database.dart';
import 'package:alcohol_project/shared/loading.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:alcohol_project/models/Board.dart';
import 'package:provider/provider.dart';

class memoBuilder extends StatefulWidget {
  //const memoBuilder({Key? key}) : super(key: key);

  @override
  _memoBuilderState createState() => _memoBuilderState();
}

class _memoBuilderState extends State<memoBuilder> {
  @override
  Widget build(BuildContext context) {

    final user = Provider.of<MyUser>(context);


    void deleteAlt(BuildContext context,Board board) async{
      String result = await showDialog(
        context: context,
        barrierDismissible: false,// 주변 클릭 안되게 하는 기능
        builder: (BuildContext context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0)),
            title: Text('삭제 경고'),
            // content: Text("정말 삭제하시겠습니까? \n uid : ${board.uid} date : ${board.date}"),
            content: Text("정말 삭제하시겠습니까? \n"),
            actions: <Widget>[
              FlatButton(
                child: Text('삭제'),
                onPressed: () async{
                  if(user.uid == board.uid){
                    await DatabaseService(uid : user.uid).board_removMemo(// updata버튼 누르면 설정한 값들을 이용해서 firestore에 데이터를 바로 업데이트
                        board.date
                    );
                  }
                  else{
                    print("다른 사용자의 게시물을 삭제할 수 없습니다. ");
                    // showDialog(
                    //   context: context,
                    //   barrierDismissible: false,// 주변 클릭 안되게 하는 기능
                    //   builder: (BuildContext context) {
                    //     return AlertDialog(
                    //       shape: RoundedRectangleBorder(
                    //
                    //         borderRadius: BorderRadius.circular(10.0)),
                    //       title: Text('삭제 에러'),
                    //       content: Text('다른 사용자의 게시물을 삭제할 수 없습니다. '),
                    //       actions: [
                    //         FlatButton(
                    //           child: Text('돌아가기'),
                    //           onPressed: (){
                    //             Navigator.pop(context);
                    //           },
                    //         )
                    //       ],
                    //     );
                    //   }
                    // );
                  }

                  Navigator.pop(context,'삭제');

                },
              ),
              FlatButton(
                child: Text('취소'),
                onPressed: () {

                  Navigator.pop(context,'취소');
                },
              )
            ],
          );
        }
      );

      if (result == '삭제'){

      }
    }

    return StreamBuilder<List<Board>>(//메모 리스트 불러오는 곳
      stream: DatabaseService(uid: user.uid).Boarder_info,//모든 board 정보 가져옴
      builder: (context, snap) {
        if (snap.data == null || snap.data!.isEmpty) {//게시물이 아무것도 없을 경우
          return Container(
            alignment: Alignment.center,
            child: Text(
              '지금 바로 "게시물 추가" 버튼을 눌러\n새로운 게시물을 추가해보세요!\n\n\n\n\n\n\n\n\n',
              style: TextStyle(fontSize: 15, color: Colors.blueAccent),
              textAlign: TextAlign.center,
            ),
          );
        }
        if(snap.hasData){
          return ListView.builder(// 게시물이 하나라도 존재하면 실행
            // physics: BouncingScrollPhysics(),
            // padding: EdgeInsets.all(20),

            itemCount: snap.data!.length,
            itemBuilder: (context, index) {
              return InkWell(
                onTap: (){},
                onLongPress: () async{
                  print('Boarder Info : ${snap.data![index].title}');
                  deleteAlt(context,snap.data![index]);
                  // Navigator.push(
                  //   context,
                  //   CupertinoPageRoute(
                  //       builder : (context) =>
                  //           DeleteAlt(board : snap.data![index]),
                  //           //DeleteAlt(uid : snap.data![index].uid, date : snap.data![index].date),
                  //       // maintainState : false,
                  //   ),
                  // );
                },
                child: BoarderTile(board : snap.data![index]),
              );
              //Board memo = snap.data![index];
              // return InkWell(
              //   onTap: () {
              //     Navigator.push(
              //         parentContext,
              //         CupertinoPageRoute(
              //             builder: (context) => ViewPage(id: memo.id)));
              //   },
              //   onLongPress: () {
              //     deleteId = memo.id;
              //     showAlertDialog(parentContext);
              //   },
              //   child: Container(
              //       margin: EdgeInsets.all(5),
              //       padding: EdgeInsets.all(15),
              //       alignment: Alignment.center,
              //       height: 100,
              //       child: Column(
              //         mainAxisAlignment: MainAxisAlignment.center,
              //         crossAxisAlignment: CrossAxisAlignment.stretch,
              //         children: <Widget>[
              //           Column(
              //             mainAxisAlignment: MainAxisAlignment.center,
              //             crossAxisAlignment: CrossAxisAlignment.stretch,
              //             children: <Widget>[
              //               Text(
              //                 memo.title,
              //                 style: TextStyle(
              //                   fontSize: 20,
              //                   fontWeight: FontWeight.w500,
              //                 ),
              //                 overflow: TextOverflow.ellipsis,
              //               ),
              //               Text(
              //                 memo.text,
              //                 style: TextStyle(fontSize: 15),
              //                 overflow: TextOverflow.ellipsis,
              //               ),
              //             ],
              //           ),
              //         ],
              //       ),
              //       decoration: BoxDecoration(
              //         color: Color.fromRGBO(240, 240, 240, 1),
              //         border: Border.all(
              //           color: Colors.blue,
              //           width: 1,
              //         ),
              //         boxShadow: [
              //           BoxShadow(color: Colors.lightBlue, blurRadius: 3)
              //         ],
              //         borderRadius: BorderRadius.circular(12),
              //       )),
              // );

              // return InkWell(
              //   onTap: (){
              //
              //   },
              //   onLongPress: () {// 길게 누르면 동작
              //     // print(memo.user_uid);
              //     // if(memo.user_uid == user.uid){ // 게시물의 uid와 현재 계정 사용자의 uid가 같으면 삭제 가능
              //     //   deleteId = memo.user_uid;//해당 메모의 id가 삭제됨
              //     //   setState(() {
              //     //     showAlertDialog(parentContext);
              //     //   });
              //     //
              //     // }else{ // uid가 다르면 삭제 권한이 없음
              //     //   print("다른사람의 게시물을 삭제할 수 없습니다. ");
              //     // }
              //   },
              //   child: Container(
              //     margin: EdgeInsets.all(5),
              //     padding: EdgeInsets.all(10),
              //     alignment: Alignment.center,
              //     // height : 80,
              //     child: Column(
              //       mainAxisAlignment: MainAxisAlignment.center,
              //       crossAxisAlignment: CrossAxisAlignment.center,
              //       children: <Widget>[
              //         Column(
              //           children: <Widget>[
              //             Text(memo.title,
              //               style: TextStyle(
              //                 fontSize: 20,
              //                 fontWeight: FontWeight.w500,
              //               ),
              //             ),
              //             Text(memo.text,
              //               style : TextStyle(
              //                 fontSize: 15,
              //               ),
              //             ),
              //           ],
              //         ),
              //
              //         // Widget to display the list of project
              //       ],
              //     ),
              //     decoration: BoxDecoration(
              //       color: Colors.grey[50],
              //       border : Border.all(
              //         color: Colors.blue,
              //         width: 1,
              //       ),
              //       boxShadow: [BoxShadow(
              //         color: Colors.blue,
              //         blurRadius: 4,
              //       )],
              //       borderRadius: BorderRadius.circular(12),
              //     ),
              //   ),
              // );
            },
          );
        }else{//데이터 불러올동안 실행
          return Loading();
        }
      },
    );
  }
}

