
//firestore에 있는 컬렉션 중 설정한 value값들을 가져오는 곳
class Coffee{
  late final String name;
  late final String sugars;
  late final int strength;

  Coffee({required this.name, required this.sugars, required this.strength});


}