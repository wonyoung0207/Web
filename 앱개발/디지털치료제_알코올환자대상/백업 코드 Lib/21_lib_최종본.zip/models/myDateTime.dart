class myDateTime {
  final String cur_dateTime;

  myDateTime({required this.cur_dateTime});



}