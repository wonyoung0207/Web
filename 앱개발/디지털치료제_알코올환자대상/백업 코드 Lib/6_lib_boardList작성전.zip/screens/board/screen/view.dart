import 'package:alcohol_project/models/Board.dart';
import 'package:alcohol_project/models/Person.dart';
import 'package:alcohol_project/models/user.dart';
import 'package:alcohol_project/screens/board/db/memo.dart';
import 'package:alcohol_project/service/database.dart';
import 'package:alcohol_project/shared/loading.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'edit.dart';
import 'package:alcohol_project/screens/board/db/db.dart';
// import 'package:memomemo/screens/view.dart';
import 'package:flutter/src/material/flat_button.dart';

class MyHomePage extends StatefulWidget {

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String deleteId = '';
  @override
  Widget build(BuildContext context) {

    // final member_info = Provider.of<List<Person>>(context);//home.dart 에서 streamProvider로 Person<List> 형식으로 데이터 가져옴
    final user = Provider.of<MyUser>(context);


    return StreamBuilder<List<Board>>(
      stream: DatabaseService(uid:user.uid).Boarder_info,
      builder: (context, snapshot) {
        if(!snapshot.hasData){
          return Loading();
        }
        else{
          // final user_selfData = Provider.of<member_UserData>(context) ?? [];
          return Scaffold(
            endDrawer: Drawer(
              //side menu 구현(메뉴화면)
              child: ListView(
                children: <Widget>[
                  Container(
                    height: 55.0, // 사용자 정보 목록 높이 설정
                    child: DrawerHeader(
                      //사용자 정보 목록
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          CircleAvatar(
                            //backgroundImage: ,
                            radius: 25.0,
                          ),
                          Expanded(
                            child: Text(
                              "OOO사용자님",
                              style: TextStyle(
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          Icon(Icons.menu),
                        ],
                      ),
                    ),
                  ),
                  // Divider(height: 3.0, color: Colors.black,),

                  Container(
                    color: Colors.grey[300],
                    height: 150,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(5.0, 30.0, 0.0, 0.0),
                      child: ListTile(
                        //절약 비용 목록
                        title: Text(
                          "절약 비용 목록\n오늘까지 절약한 비용 : 580,000\n오늘 절약한 비용 : 12,000",
                          style: TextStyle(
                            fontSize: 18.0,
                          ),
                        ),
                      ),
                    ),
                  ),

                  Divider(
                    height: 3.0,
                    color: Colors.black,
                  ),
                  Container(
                    height: 55,
                    child: ListTile(
                      //커뮤니티 목록
                      title: Text(
                        "커뮤니티 목록",
                        style: TextStyle(
                          fontSize: 20.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      // onTap: () => {
                      //   Navigator.push(
                      //     context,
                      //     // MaterialPageRoute(
                      //     //   builder: (context) => Communication(key: key, title: '커뮤니티',),
                      //     // ),
                      //   ),
                      //   // Navigator.pop(context),
                      // },
                    ),
                  ),
                  Divider(
                    height: 3.0,
                    color: Colors.black,
                  ),
                ],
              ),
            ),
            appBar: AppBar(
              title: Text("커뮤니티"),
            ),

            body: Column(
              children: <Widget>[
                // Padding(
                //   padding: EdgeInsets.only(left: 20, top: 40, bottom: 20),
                //   // child: Container(
                //   //   child: Text('메모메모',
                //   //       style: TextStyle(fontSize: 36, color: Colors.blue)),
                //   //   alignment: Alignment.centerLeft,
                //   // ),
                // ),
                Expanded(child: memoBuilder(context))
              ],
            ),
            floatingActionButton: FloatingActionButton.extended(//버튼 클릭시 개시물 작성할수 있도록
              onPressed: () {
                Navigator.push(
                  context,
                  CupertinoPageRoute(
                    builder: (context) => EditPage(
                    ),
                  ),
                );
              },
              tooltip: "게시물을 작성하세요",
              label: Text('게시물 추가'),
              icon: Icon(Icons.add),
            ), // This trailing comma makes auto-formatting nicer for build methods.
          );
        }

      }
    );
  }

  Future<List<Memo>> loadMemo() async {
    DBHelper sd = DBHelper();
    return await sd.memos();
  }

  Future<void> deleteMemo(String id) async {
    DBHelper sd = DBHelper();
    await sd.deleteMemo(id);
  }

  //delete yes or no
  void showAlertDialog(BuildContext context) async {// 게시물 삭제시 사용할 메소드
    String result = await showDialog(
        context: context,
        barrierDismissible: false, // user must tap button!
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('삭제 경고'),
            content: Text("정말 삭제하시겠습니까?"),
            actions: <Widget>[
              FlatButton(
                child: Text('삭제'),
                onPressed: () {
                  Navigator.pop(context, "삭제");
                  setState(() {
                    deleteMemo(deleteId);
                  });
                  deleteId = '';
                },
              ),
              FlatButton(
                child: Text('취소'),
                onPressed: () {
                  deleteId = '';
                  Navigator.pop(context, "취소");
                },
              )
            ],
          );
        }
    );
  }

  // void showAlertDialog(BuildContext context) async {
  //   await showDialog(
  //     context: context,
  //     barrierDismissible: false, // user must tap button!
  //     builder: (BuildContext context) {
  //       return AlertDialog(
  //         title: Text('삭제 경고'),
  //         content: Text("정말 삭제하시겠습니까?\n삭제된 게시물은 복구되지 않습니다."),
  //         actions: <Widget>[
  //           FlatButton(
  //             child: Text('삭제'),
  //             onPressed: () {
  //               Navigator.pop(context, "삭제");
  //               setState(() {
  //                 deleteMemo(deleteId);
  //               });
  //               deleteId = '';
  //             },
  //           ),
  //           FlatButton(
  //             child: Text('취소'),
  //             onPressed: () {
  //               deleteId = '';
  //               Navigator.pop(context, "취소");
  //             },
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  Widget memoBuilder(BuildContext parentContext) {

    return StreamBuilder<List<Board>>(//메모 리스트 불러오는 곳
      builder: (context, snap) {
        if (snap.data == null || snap.data!.isEmpty) {//게시물이 아무것도 없을 경우
          return Container(
            alignment: Alignment.center,
            child: Text(
              '지금 바로 "게시물 추가" 버튼을 눌러\n새로운 게시물을 추가해보세요!\n\n\n\n\n\n\n\n\n',
              style: TextStyle(fontSize: 15, color: Colors.blueAccent),
              textAlign: TextAlign.center,
            ),
          );
        }
        if(snap.hasData){
          return ListView.builder(// 게시물이 하나라도 존재하면 실행
            physics: BouncingScrollPhysics(),
            padding: EdgeInsets.all(20),
            itemCount: snap.data!.length,
            itemBuilder: (context, index) {
              Board memo = snap.data![index];
              // return InkWell(
              //   onTap: () {
              //     Navigator.push(
              //         parentContext,
              //         CupertinoPageRoute(
              //             builder: (context) => ViewPage(id: memo.id)));
              //   },
              //   onLongPress: () {
              //     deleteId = memo.id;
              //     showAlertDialog(parentContext);
              //   },
              //   child: Container(
              //       margin: EdgeInsets.all(5),
              //       padding: EdgeInsets.all(15),
              //       alignment: Alignment.center,
              //       height: 100,
              //       child: Column(
              //         mainAxisAlignment: MainAxisAlignment.center,
              //         crossAxisAlignment: CrossAxisAlignment.stretch,
              //         children: <Widget>[
              //           Column(
              //             mainAxisAlignment: MainAxisAlignment.center,
              //             crossAxisAlignment: CrossAxisAlignment.stretch,
              //             children: <Widget>[
              //               Text(
              //                 memo.title,
              //                 style: TextStyle(
              //                   fontSize: 20,
              //                   fontWeight: FontWeight.w500,
              //                 ),
              //                 overflow: TextOverflow.ellipsis,
              //               ),
              //               Text(
              //                 memo.text,
              //                 style: TextStyle(fontSize: 15),
              //                 overflow: TextOverflow.ellipsis,
              //               ),
              //             ],
              //           ),
              //         ],
              //       ),
              //       decoration: BoxDecoration(
              //         color: Color.fromRGBO(240, 240, 240, 1),
              //         border: Border.all(
              //           color: Colors.blue,
              //           width: 1,
              //         ),
              //         boxShadow: [
              //           BoxShadow(color: Colors.lightBlue, blurRadius: 3)
              //         ],
              //         borderRadius: BorderRadius.circular(12),
              //       )),
              // );
              return InkWell(
                onTap: (){

                },
                onLongPress: () {// 길게 누르면 동작
                  // print(memo.user_uid);
                  // if(memo.user_uid == user.uid){ // 게시물의 uid와 현재 계정 사용자의 uid가 같으면 삭제 가능
                  //   deleteId = memo.user_uid;//해당 메모의 id가 삭제됨
                  //   setState(() {
                  //     showAlertDialog(parentContext);
                  //   });
                  //
                  // }else{ // uid가 다르면 삭제 권한이 없음
                  //   print("다른사람의 게시물을 삭제할 수 없습니다. ");
                  // }
                },
                child: Container(
                  margin: EdgeInsets.all(5),
                  padding: EdgeInsets.all(10),
                  alignment: Alignment.center,
                  // height : 80,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          Text(memo.title,
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          Text(memo.text,
                            style : TextStyle(
                              fontSize: 15,
                            ),
                          ),
                        ],
                      ),

                      // Widget to display the list of project
                    ],
                  ),
                  decoration: BoxDecoration(
                    color: Colors.grey[50],
                    border : Border.all(
                      color: Colors.blue,
                      width: 1,
                    ),
                    boxShadow: [BoxShadow(
                      color: Colors.blue,
                      blurRadius: 4,
                    )],
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              );
            },
          );
        }else{//데이터 불러올동안 실행
          return Loading();
        }
      },
      // future: loadMemo(),
    );
  }
}
