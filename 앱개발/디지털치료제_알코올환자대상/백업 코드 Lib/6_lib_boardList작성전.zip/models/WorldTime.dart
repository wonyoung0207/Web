import 'dart:convert';
import 'package:http/http.dart';
import 'package:intl/intl.dart';


class WorldTime{

  late String time;
  late String location;
  late String flag;
  late String url;
  late bool isDaytime;

  WorldTime({ required this.location,required this.flag,required this.url});

  Future<void> getTime() async{

    try{
      // 현재 한국 서울의 시간을 json으로 가져와서 offset을 기준으로 출력 ㄴ
      Response response1 = await get(Uri.parse('https://worldtimeapi.org/api/timezone/$url'));
      Map data = jsonDecode(response1.body);

      String datetime = data['datetime'];
      String offset1 = data['utc_offset'].substring(1,3);
      String offset2 = data['utc_offset'].substring(4,6);

      DateTime now = DateTime.parse(datetime);

      // now 만 하게 된다면 날짜는 잘 나오지만, 시간이 utc 기준출력하기 때문에 이상하게 나온다.
      // 따라서 utc만큼 시간을 더해줘야 정확한 시간을 알 수 있따.
      now = now.add(Duration(hours: int.parse(offset1), minutes: int.parse(offset2)));

      isDaytime = now.hour > 6 && now.hour < 20 ? true : false;
      //time = now.toString();
      time = DateFormat("dd.MM.yy HH:mm:ss").format(now);
      //time = DateFormat.jm().format(now);

    }
    catch(e){
      print('myError exception : $e');
      time = 'Could not get time data';
    }
  }

}