// import 'package:alcohol_project/models/Board.dart';
// import 'package:alcohol_project/models/user.dart';
// import 'package:alcohol_project/service/database.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
//
//
// class DeleteAlt extends StatelessWidget {
//   //const DeleteAlt({Key? key}) : super(key: key);
//
//
//   // final String uid;
//   // final String date;
//   final Board board;
//
//
//   //DeleteAlt({required this.uid, required this.date});
//   DeleteAlt({required this.board});
//
//   @override
//   Widget build(BuildContext context) {
//
//     final user = Provider.of<MyUser>(context);
//
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('삭제 에러'),
//       ),
//       body: AlertDialog(
//         shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(10.0)),
//         title: Text('삭제 경고'),
//         // content: Text("정말 삭제하시겠습니까? \n uid : ${this.board.uid} date : ${this.board.date}"),
//         content: Text("정말 삭제하시겠습니까? \n"),
//         actions: <Widget>[
//           FlatButton(
//             child: Text('삭제'),
//             onPressed: () async{
//               if(user.uid == board.uid){
//                 await DatabaseService(uid : user.uid).board_removMemo(// updata버튼 누르면 설정한 값들을 이용해서 firestore에 데이터를 바로 업데이트
//                   board.date
//                 );
//               }
//               else{
//                 print("다른 사용자의 게시물을 삭제할 수 없습니다. ");
//                 // AlertDialog(
//                 //   title: Text('삭제 에러'),
//                 //   content: Text('다른 사용자의 게시물을 삭제할 수 없습니다. '),
//                 //   actions: [
//                 //     FlatButton(
//                 //       child: Text('돌아가기'),
//                 //       onPressed: (){
//                 //         Navigator.pop(context);
//                 //       },
//                 //     )
//                 //   ],
//                 // );
//               }
//
//               Navigator.pop(context);
//
//             },
//           ),
//           FlatButton(
//             child: Text('취소'),
//             onPressed: () {
//
//               Navigator.pop(context);
//             },
//           )
//         ],
//       ),
//
//
//       // body: AlertDialog(
//       //   shape: RoundedRectangleBorder(
//       //       borderRadius: BorderRadius.circular(10.0)),
//       //   title: Text('삭제 경고'),
//       //   content: Text("정말 삭제하시겠습니까? \n uid : ${this.board.uid} date : ${this.board.date}"),
//       //   actions: <Widget>[
//       //     FlatButton(
//       //       child: Text('삭제'),
//       //       onPressed: () async{
//       //         if(user.uid == board.uid){
//       //           await DatabaseService(uid : user.uid).board_removMemo(// updata버튼 누르면 설정한 값들을 이용해서 firestore에 데이터를 바로 업데이트
//       //               board.date
//       //           );
//       //         }
//       //         else{
//       //           print("다른 사용자의 게시물을 삭제할 수 없습니다. ");
//       //           // AlertDialog(
//       //           //   title: Text('삭제 에러'),
//       //           //   content: Text('다른 사용자의 게시물을 삭제할 수 없습니다. '),
//       //           //   actions: [
//       //           //     FlatButton(
//       //           //       child: Text('돌아가기'),
//       //           //       onPressed: (){
//       //           //         Navigator.pop(context);
//       //           //       },
//       //           //     )
//       //           //   ],
//       //           // );
//       //         }
//       //
//       //         Navigator.pop(context);
//       //
//       //       },
//       //     ),
//       //     FlatButton(
//       //       child: Text('취소'),
//       //       onPressed: () {
//       //
//       //         Navigator.pop(context);
//       //       },
//       //     )
//       //   ],
//       // ),
//     );
//   }
// }