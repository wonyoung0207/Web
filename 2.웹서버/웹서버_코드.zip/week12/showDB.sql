show tables;

